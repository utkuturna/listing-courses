/*
 * @todo add tests about course list
 *   - Check if table is rendering if there is no course
 *   - Check if table is rendering the correct number of rows
 *   - Check if user can sort the table with clicking
 *   - Check if table is sorted by id initially
 *   - Check if table has id and name fields correctly
 * */
