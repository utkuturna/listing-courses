export const MOCK_COURSE_DETAIL = {
  result: {
    id: 1,
    name: 'RU - Linear Algebra',
    description: 'This course teaches you the basics of statistics',
  },
};
