export const MOCK_COURSES = {
  count: 4,
  result: [
    {
      id: 1,
      name: 'RU - Statistics',
    },
    {
      id: 2,
      name: 'Assessment Course',
    },
    {
      id: 3,
      name: 'TUD - Math',
    },
    {
      id: 4,
      name: 'EUR - Statistics',
    },
  ],
};
